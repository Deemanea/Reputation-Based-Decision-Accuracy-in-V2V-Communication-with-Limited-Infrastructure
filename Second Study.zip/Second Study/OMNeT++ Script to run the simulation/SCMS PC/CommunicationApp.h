#ifndef VEINS_MODULES_APPLICATION_REPUTATIONCOMMUNICATION_REPUTATIONCOMMUNICATIONAPP_H_
#define VEINS_MODULES_APPLICATION_REPUTATIONCOMMUNICATION_REPUTATIONCOMMUNICATIONAPP_H_

#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"
#include "veins/modules/application/ReputationCommunication/ReputationCommunicationAppMessage_m.h"
#include "veins/modules/mobility/traci/TraCIMobility.h"
#include "veins/modules/mobility/traci/TraCICommandInterface.h"

#include <cryptopp/rsa.h>
#include <cryptopp/hex.h>
#include <cryptopp/osrng.h>
#include <cryptopp/filters.h>
#include <cryptopp/files.h>
#include <cryptopp/pssr.h>
#include <cryptopp/secblock.h>
#include <cryptopp/base64.h>
#include <string>
#include <vector>

namespace veins {

struct NodeState {
    int NodeId;
    bool Attacker;
    double NodeScore;
    std::vector<CryptoPP::RSA::PrivateKey> privateKeys;
    std::vector<CryptoPP::RSA::PublicKey> publicKeys;
    std::vector<std::string> certificates; // Pseudonym certificates signed by CA
    bool validCertificate;
};

class VEINS_API ReputationCommunicationApp : public DemoBaseApplLayer {
public:
    void initialize(int stage) override;
    void finish() override;

protected:
    simtime_t lastDroveAt;
    bool sentMessage;
    int currentSubscribedServiceId;
    int MNodeId;
    bool HasAccident;
    int RouteChangeRequested;
    double MScore;
    double Threshold_Score;
    double AttackStart;
    double AttackDuration;
    cMessage* AttackTimer;
    std::list<NodeState> MyNodeList;
    std::list<NodeState> MyScoreList;
    CryptoPP::RSA::PrivateKey caPrivateKey;
    CryptoPP::RSA::PublicKey caPublicKey;

    // Declare Attacker variable
    bool Attacker;

    // Declare accident position
    Coord accidentPosition;

    // Mobility components
    veins::TraCIMobility* mobility;
    veins::TraCICommandInterface* traci;
    veins::TraCICommandInterface::Vehicle* traciVehicle;

    // Helper functions for signing and verification
    std::string signMessage(const std::string& message, const CryptoPP::RSA::PrivateKey& privKey);
    bool verifyMessage(const std::string& message, const std::string& signature, const CryptoPP::RSA::PublicKey& pubKey);
    std::string signCertificate(const std::string& certificate);
    bool verifyCertificate(const std::string& certificate);  // Modified to remove signature parameter
    CryptoPP::RSA::PublicKey extractPublicKeyFromCert(const std::string& certificate); // New function declaration
    std::string extractCertData(const std::string& certificate);  // New function declaration
    std::string extractCertSignature(const std::string& certificate);  // New function declaration
    double GetReputationScoreofNode(int nodeId);

    // Statistics
    int messagesSent;
    int messagesReceived;
    int validMessagesReceived;
    int invalidMessagesReceived;
    int truePositiveDecisions; // Updated based on new requirements
    int falsePositiveDecisions; // For false positive tracking
    int invalidReputationMessages;
    int invalidCertificateMessages;
    int forwardedMessages;
    double responseTime; // for measuring total response time
    int correctDecisions; // To calculate decision accuracy

    // New Metrics and Variables Added:

    // Message Propagation Delay (new)
    double messagePropagationDelay;  // To track individual message delays

    // Decision Metrics
    int trueNegativeDecisions;   // True negative messages
    int falseNegativeDecisions;  // False negative messages

    // Calculated metrics (Precision, Recall, F1 Score, etc.)
    double precision;
    double recall;
    double specificity;
    double f1Score;

    // Reputation-specific variables
    double MRV;
    int highRepCount;
    int lowRepCount;

    // Reputation file handling
    std::string ReputationFile;
    void GenerateFile();
    void ReadReputationFile();
    void SetMyReputationState();
    void UpdateReputationKnowledge(int nodeId, double score);
    void logAttackDetails(const std::string& action);
    void updateDisplayString(const std::string& info);

    // Key generation functions
    void generateKeys();
    void generateCACertificate();
    void generateVehicleCertificates(NodeState& node);
    void storeKeysAndCertificates(NodeState& node);

    // Message handling functions
    void sendDENMMessage();
    void simulateSybilAttack();

    // Decay-related parameters
    double decayRate;        // Decay rate for reputation
    double decayInterval;    // Time interval for decay

    // Message handling functions
    void applyReputationDecay();   // Apply reputation decay over time
    bool checkLocalCertificateValidity(int nodeId);

protected:
    void onWSM(BaseFrame1609_4* wsm) override;
    void onWSA(DemoServiceAdvertisment* wsa) override;
    void handleSelfMsg(cMessage* msg) override;
    void handlePositionUpdate(cObject* obj) override;
    bool isSybilAttackMessage(int nodeId);
    void forwardMessage(ReputationCommunicationAppMessage* msg); // Forward message handling
};

} // namespace veins

#endif // VEINS_MODULES_APPLICATION_REPUTATIONCOMMUNICATION_REPUTATIONCOMMUNICATIONAPP_H_


