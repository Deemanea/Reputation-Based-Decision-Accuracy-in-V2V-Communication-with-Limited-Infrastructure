
#include "veins/modules/application/ReputationCommunication/ReputationCommunicationApp.h"
#include "veins/modules/application/ReputationCommunication/ReputationCommunicationAppMessage_m.h"
#include "veins/modules/mobility/traci/TraCIMobility.h"
#include "veins/modules/mobility/traci/TraCICommandInterface.h"

#include <cryptopp/rsa.h>
#include <cryptopp/hex.h>
#include <cryptopp/osrng.h>
#include <cryptopp/files.h>
#include <cryptopp/pssr.h>
#include <sstream>
#include <fstream>
#include <string>

using namespace veins;
using namespace CryptoPP;

Define_Module(veins::ReputationCommunicationApp);

void ReputationCommunicationApp::initialize(int stage)
{
    DemoBaseApplLayer::initialize(stage);
    if (stage == 0) {
        lastDroveAt = simTime();
        currentSubscribedServiceId = -1;
        sentMessage = false;
        ReputationFile = par("ReputationFile").stringValue();
        MNodeId = findHost()->getIndex();
        Threshold_Score = par("Threshold_Score").doubleValue();
        HasAccident = par("HasAccident").boolValue();
        RouteChangeRequested = false;

        MRV = par("MRV").doubleValue();
        highRepCount = 0;
        lowRepCount = 0;

        messagesSent = 0;
        messagesReceived = 0;
        validMessagesReceived = 0;
        invalidMessagesReceived = 0;
        forwardedMessages = 0;
        responseTime = 0.0;
        correctDecisions = 0;



               // Initialize new metrics
               truePositiveDecisions = 0;
               falsePositiveDecisions = 0;
               trueNegativeDecisions = 0;
               falseNegativeDecisions = 0;

               precision = 0.0;
               recall = 0.0;
               specificity = 0.0;
               f1Score = 0.0;

               NodeState myNode;
               myNode.NodeId = MNodeId;


        // Generate keys and certificates if not already done
        auto it = std::find_if(MyNodeList.begin(), MyNodeList.end(), [&](const NodeState& node) {
            return node.NodeId == MNodeId;
        });

        if (it == MyNodeList.end()) {
            generateKeys();
            generateCACertificate();
            generateVehicleCertificates(myNode);
            storeKeysAndCertificates(myNode);
            MyNodeList.push_back(myNode);
            EV << "Generated keys and certificates for Node " << MNodeId << endl;
        } else {
            myNode = *it;
            EV << "Using existing keys and certificates for Node " << MNodeId << endl;
        }
        // New parameters for reputation/certificate system
            //reputationBased = par("reputationBased").boolValue(); // Toggle between reputation and certificate systems
            //decayRate = par("decayRate").doubleValue();           // Decay rate for reputation-based system
            //decayInterval = par("decayInterval").doubleValue();   // Time interval for decay in reputation system

            // Schedule decay event if using the reputation system
            //if (reputationBased) {
                //scheduleAt(simTime() + decayInterval, new cMessage("ApplyDecay"));
            //}



        ReadReputationFile();
        SetMyReputationState();

        if (MNodeId == 1 || MNodeId == 5 || MNodeId == 8) {
            scheduleAt(simTime(), new cMessage("SendDENMMessage"));
        }

        AttackStart = par("AttackStart").doubleValue();
        AttackDuration = par("AttackDuration").doubleValue();

        if (Attacker) {
            scheduleAt(simTime() + AttackStart, new cMessage("SybilAttackStart"));
        }

        mobility = TraCIMobilityAccess().get(findHost());
        traci = mobility->getCommandInterface();
        EV << "Initialization completed for Node " << MNodeId << endl;
    }
}

void ReputationCommunicationApp::finish()
{

        recordScalar("MessagesSent", messagesSent);
        recordScalar("MessagesReceived", messagesReceived);
        recordScalar("ValidMessagesReceived", validMessagesReceived);
        recordScalar("InvalidMessagesReceived", invalidMessagesReceived);
        recordScalar("FinalReputationScore", MScore);
        recordScalar("ForwardedMessages", forwardedMessages);

        // Calculate average propagation delay
        if (messagesReceived > 0) {
            double avgPropagationDelay = responseTime / messagesReceived;
            recordScalar("AveragePropagationDelay", avgPropagationDelay);
            EV << "Average Message Propagation Delay: " << avgPropagationDelay << " seconds" << endl;
        }

        // Calculate Precision, Recall, Specificity, F1 Score
        double TP = truePositiveDecisions;
        double FP = falsePositiveDecisions;
        double TN = trueNegativeDecisions;
        double FN = falseNegativeDecisions;

        if (TP + FP > 0) precision = TP / (TP + FP);  // Precision: TP / (TP + FP)
        if (TP + FN > 0) recall = TP / (TP + FN);      // Recall (Sensitivity): TP / (TP + FN)
        if (TN + FP > 0) specificity = TN / (TN + FP); // Specificity: TN / (TN + FP)
        if (precision + recall > 0) f1Score = 2 * (precision * recall) / (precision + recall);  // F1 Score

        // Record calculated metrics
        recordScalar("TruePositive", TP);
        recordScalar("FalsePositive", FP);
        recordScalar("TrueNegative", TN);
        recordScalar("FalseNegative", FN);

        recordScalar("Precision", precision);
        recordScalar("Recall (Sensitivity)", recall);
        recordScalar("Specificity", specificity);
        recordScalar("F1 Score", f1Score);

        EV << "Precision: " << precision << endl;
        EV << "Recall (Sensitivity): " << recall << endl;
        EV << "Specificity: " << specificity << endl;
        EV << "F1 Score: " << f1Score << endl;

        if (messagesReceived > 0) {
            recordScalar("AverageResponseTime", responseTime / messagesReceived);
            double accuracy = (double)correctDecisions / messagesReceived;
            recordScalar("DecisionAccuracy", accuracy);
        }

        // Record reputation-based messages
        recordScalar("TruePositive", correctDecisions);
        recordScalar("FalsePositive", messagesReceived - correctDecisions);
        recordScalar("HighReputationMessages", highRepCount);
        recordScalar("LowReputationMessages", lowRepCount);

        EV << "Node " << MNodeId << " finished execution." << endl;
}

void ReputationCommunicationApp::onWSA(DemoServiceAdvertisment* wsa)
{
    if (currentSubscribedServiceId == -1) {
        mac->changeServiceChannel(static_cast<Channel>(wsa->getTargetChannel()));
        currentSubscribedServiceId = wsa->getPsid();
        if (currentOfferedServiceId != wsa->getPsid()) {
            stopService();
            startService(static_cast<Channel>(wsa->getTargetChannel()), wsa->getPsid(), "Mirrored Traffic Service");
        }
        EV << "Node " << MNodeId << " subscribed to service " << wsa->getPsid() << " on channel " << wsa->getTargetChannel() << endl;
    }
}

void ReputationCommunicationApp::onWSM(BaseFrame1609_4* frame)

{
    EV << "onWSM called" << endl;
    simtime_t messageReceivedTime = simTime();  // Capture the time when the message is received

    // Cast the incoming message to the appropriate type
    ReputationCommunicationAppMessage* wsm = check_and_cast<ReputationCommunicationAppMessage*>(frame);

    // Log the demo data immediately after casting
    EV << "Received demo data: " << wsm->getDemoData() << endl;

    LAddress::L2Type senderAddr = wsm->getSenderAddress();
    int nodeId = senderAddr;
    messagesReceived++;

    // Get the accident data from the message
    std::string accidentData = wsm->getDemoData();

    // Log the accident data and HasAccident flag for debugging
    EV << "Accident data received: " << accidentData << endl;
    EV << "HasAccident: " << HasAccident << endl;

    // Proceed with the rest of the logic (e.g., propagation delay, distance checks, etc.)


    // Propagation delay (End-to-end delay)
       simtime_t propagationDelay = simTime() - wsm->getTimestamp();
       EV << "Message propagation delay: " << propagationDelay << " seconds." << endl;
       recordScalar("PropagationDelay", propagationDelay);

       // 2. Distance-based decision-making
       Coord senderPosition = wsm->getSenderPosition();  // Assuming sender position is included in the message
       double distance = mobility->getCurrentDirection().distance(senderPosition);
       EV << "Distance from sender: " << distance << " meters." << endl;
       recordScalar("SenderReceiverDistance", distance);

       // 3. Message rate tracking (Event congruency)
       simtime_t lastMessageTime = wsm->getTimestamp();
       double messageRate = messagesReceived / (simTime() - lastMessageTime);
       EV << "Message rate: " << messageRate << " messages per second." << endl;
       recordScalar("MessageRate", messageRate);

       // Suspicion level calculation
       double suspicionLevel = 0.0;
       if (propagationDelay > 0.2) {  // Example threshold for delay
           suspicionLevel += 0.3;
           EV << "Propagation delay too high. Increasing suspicion level by 0.3" << endl;
       }
       if (distance > 500) {  // Example threshold for distance
           suspicionLevel += 0.4;
           EV << "Sender too far away. Increasing suspicion level by 0.4" << endl;
       }
       if (messageRate > 1) {  // Example threshold for message rate
           suspicionLevel += 0.3;
           EV << "Message rate too high. Increasing suspicion level by 0.3" << endl;
       }
       recordScalar("SuspicionLevel", suspicionLevel);

       // Decision-making logic based on certificate validity and reputation
       bool isCertificateValid = checkLocalCertificateValidity(nodeId);
       double senderReputation = GetReputationScoreofNode(nodeId);

       // Log reputation and certificate status
       EV << "Reputation score of Node " << nodeId << ": " << senderReputation << " with certificate validity: " << isCertificateValid << endl;

       // Accident data processing
       bool isAccidentReportedCorrectly = (HasAccident && accidentData.find("Accident") != std::string::npos);
       bool isNonAccidentReportedCorrectly = (!HasAccident && accidentData.find("No Accident") != std::string::npos);

       // Adjust TP, TN, FP, FN calculations
       if (isCertificateValid && senderReputation >= Threshold_Score) {
           if (isAccidentReportedCorrectly || isNonAccidentReportedCorrectly) {
               // True Positive (valid certificate and high reputation, correct accident/non-accident report)
               EV << "Message from Node " << nodeId << " accepted (valid certificate, high reputation, and correct accident report)." << endl;
               truePositiveDecisions++;
               recordScalar("TruePositive", truePositiveDecisions);
           } else {
               // False Negative (valid certificate, high reputation, but incorrect accident report)
               EV << "Message from Node " << nodeId << " accepted (valid certificate, high reputation)" << endl;
               truePositiveDecisions++;
               recordScalar("TruePositive", truePositiveDecisions);
           }

           // Handle accident data
           if (accidentData.find("Accident") != std::string::npos) {
               if (!HasAccident) {
                   // False accident report; ignore the route change
                   EV << "False accident report detected by Node " << MNodeId << ". Ignoring route change." << endl;
                   trueNegativeDecisions++;  // Correctly identified false accident report
                   recordScalar("TrueNegative", trueNegativeDecisions);
               } else {
                   // Correct accident report; change route
                   try {
                       EV << "Attempting to change route due to accident reported by Node " << nodeId << endl;
                       EV << "Current route: " << mobility->getRoadId() << endl;  // Log current route

                       // Change route
                       traciVehicle->changeRoute("-28822164#4", 9999);  // Ensure this is a valid route ID
                       RouteChangeRequested++;  // Track route changes
                       EV << "Route changed by Node " << MNodeId << " to avoid accident." << endl;
                       recordScalar("RouteChanges", RouteChangeRequested);
                   } catch (const std::exception& e) {
                       EV << "Error changing route: " << e.what() << endl;
                   }
               }
           } else {
               EV << "No accident reported by Node " << nodeId << ". Continuing on current route." << endl;
           }

           // Forward the message if it’s valid
           if (!sentMessage) {
               EV << "Message from Node " << nodeId << " is valid. Forwarding the message." << endl;

               sentMessage = true;  // Prevent immediate duplicate forwarding
               wsm->setSerial(2);  // Increment serial for forwarding
               wsm->setSenderAddress(MNodeId);  // Set sender as the current node
               wsm->setTimestamp(simTime());  // Update timestamp

               // Schedule message forwarding
               scheduleAt(simTime() + 2 + uniform(0.01, 0.2), wsm->dup());

               forwardedMessages++;  // Track forwarded messages
               validMessagesReceived++;  // Track valid messages
               EV << "Message successfully forwarded by Node " << MNodeId << endl;
               recordScalar("MessagesForwarded", forwardedMessages);
           } else {
               EV << "Message forwarding skipped as message already sent by Node " << MNodeId << endl;
           }
       } else {
           // False Negative or False Positive based on condition
           if (!isCertificateValid && senderReputation >= Threshold_Score) {
               EV << "Message from Node " << nodeId << " rejected due to invalid certificate." << endl;
               falseNegativeDecisions++;
               recordScalar("FalseNegative", falseNegativeDecisions);
           }
           if (isCertificateValid && senderReputation < Threshold_Score) {
               EV << "Message from Node " << nodeId << " rejected due to low reputation score." << endl;
               falseNegativeDecisions++;
               recordScalar("FalseNegative", falseNegativeDecisions);
           }
           if (!isCertificateValid && senderReputation < Threshold_Score) {
               EV << "Message from Node " << nodeId << " correctly rejected due to both invalid certificate and low reputation." << endl;
               trueNegativeDecisions++;
               recordScalar("TrueNegative", trueNegativeDecisions);
           }
           if (isCertificateValid && senderReputation >= Threshold_Score) {
               EV << "Message from Node " << nodeId << " correctly accepted due to both valid certificate and high reputation." << endl;
               truePositiveDecisions++;
               recordScalar("TruePositive", truePositiveDecisions);
           }
       }

       // Log and calculate the time taken to process and validate the message
       simtime_t messageValidationTime = simTime() - messageReceivedTime;
       responseTime += messageValidationTime.dbl();
       recordScalar("MessageValidationTime", messageValidationTime.dbl());

       EV << "Message processing and decision took: " << messageValidationTime << " seconds." << endl;
   }

   // Method to detect Sybil attacks
   bool ReputationCommunicationApp::isSybilAttackMessage(int nodeId)
   {
       // Assuming any nodeId >= 100 is a Sybil attacker. Adjust this threshold based on your system.
       if (nodeId >= 100) {
           EV << "Node " << nodeId << " is identified as part of a Sybil attack." << endl;
           return true;
       }
       return false;
   }



void ReputationCommunicationApp::handleSelfMsg(cMessage* msg)



{
    if (ReputationCommunicationAppMessage* wsm = dynamic_cast<ReputationCommunicationAppMessage*>(msg)) {
        sendDown(wsm->dup());
        wsm->setSerial(wsm->getSerial() + 1);
        if (wsm->getSerial() >= 3) {
            stopService();
            delete wsm;
        } else {
            scheduleAt(simTime() + 1, wsm);
        }
        EV << "Self message handled by Node " << MNodeId << endl;
    } else if (strcmp(msg->getName(), "SybilAttackStart") == 0) {
        EV << "Starting Sybil Attack at " << simTime() << endl;
        simulateSybilAttack();
        scheduleAt(simTime() + AttackDuration, new cMessage("SybilAttackEnd"));
    } else if (strcmp(msg->getName(), "SybilAttackEnd") == 0) {
        EV << "Ending Sybil Attack at " << simTime() << endl;
    } else if (strcmp(msg->getName(), "SendDENMMessage") == 0) {
        sendDENMMessage();
        scheduleAt(simTime() + 60, new cMessage("SendDENMMessage"));
    } else {
        DemoBaseApplLayer::handleSelfMsg(msg);
    }
}

void ReputationCommunicationApp::applyReputationDecay()
{
    EV << "Applying reputation decay..." << endl;
    for (auto& node : MyScoreList) {
        if (node.NodeScore > 0) {
            node.NodeScore = std::max(0.0, node.NodeScore - decayRate); // Reduce the reputation but don't go below 0
            EV << "Node " << node.NodeId << " new reputation score: " << node.NodeScore << endl;
        }
    }

    EV << "Reputation decay applied to all nodes." << endl;
    scheduleAt(simTime() + decayInterval, new cMessage("ApplyDecay")); // Reschedule decay
}


bool ReputationCommunicationApp::checkLocalCertificateValidity(int nodeId)
{
    for (const auto& node : MyScoreList) {
        if (node.NodeId == nodeId) {
            return node.validCertificate; // Return certificate validity from the reputation file
        }
    }
    return false; // Default to invalid if node not found
}


















void ReputationCommunicationApp::handlePositionUpdate(cObject* obj)
{
    DemoBaseApplLayer::handlePositionUpdate(obj);

    if (mobility->getSpeed() < 1 && simTime() - lastDroveAt >= 20 && HasAccident) {
        findHost()->getDisplayString().setTagArg("i", 1, "yellow");
        sendDENMMessage();
        EV << "Position update: Accident detected by Node " << MNodeId << endl;
    } else {
        lastDroveAt = simTime();
    }
}

void ReputationCommunicationApp::generateKeys()
{
    AutoSeededRandomPool rng;
    caPrivateKey.GenerateRandomWithKeySize(rng, 2048);
    caPublicKey.AssignFrom(caPrivateKey);
    EV << "CA keys generated." << endl;
}

void ReputationCommunicationApp::generateCACertificate()
{
    std::string caCert;
    StringSink ss(caCert);
    caPublicKey.DEREncode(ss);
    ss.MessageEnd();
    EV << "CA certificate generated." << endl;
}

void ReputationCommunicationApp::generateVehicleCertificates(NodeState& node)
{
    AutoSeededRandomPool rng;

    for (int i = 0; i < 100; ++i) {
        RSA::PrivateKey privKey;
        privKey.GenerateRandomWithKeySize(rng, 2048);
        node.privateKeys.push_back(privKey);

        RSA::PublicKey pubKey;
        pubKey.AssignFrom(privKey);
        node.publicKeys.push_back(pubKey);

        std::string cert;
        StringSink ss(cert);
        pubKey.DEREncode(ss);
        ss.MessageEnd();

        std::string signedCert = signCertificate(cert);
        node.certificates.push_back(signedCert);
    }
    EV << "Vehicle certificates generated for Node ID: " << node.NodeId << endl;
}

void ReputationCommunicationApp::storeKeysAndCertificates(NodeState& node)
{
    std::ofstream keysFile("vehicle_keys_" + std::to_string(node.NodeId) + ".txt");
    std::ofstream certsFile("vehicle_certs_" + std::to_string(node.NodeId) + ".txt");

    for (size_t i = 0; i < node.privateKeys.size(); ++i) {
        std::string privKeyStr;
        StringSink privSink(privKeyStr);
        node.privateKeys[i].DEREncode(privSink);
        privSink.MessageEnd();
        keysFile << "PrivateKey " << i << ": " << privKeyStr << "\n";

        std::string pubKeyStr;
        StringSink pubSink(pubKeyStr);
        node.publicKeys[i].DEREncode(pubSink);
        pubSink.MessageEnd();
        keysFile << "PublicKey " << i << ": " << pubKeyStr << "\n";

        certsFile << "Certificate " << i << ": " << node.certificates[i] << "\n";
    }

    keysFile.close();
    certsFile.close();

    EV << "Keys and certificates stored for Node ID: " << node.NodeId << endl;
}

std::string ReputationCommunicationApp::signMessage(const std::string& message, const CryptoPP::RSA::PrivateKey& privKey)
{
    AutoSeededRandomPool rng;
    RSASS<PSSR, SHA256>::Signer signer(privKey);

    SecByteBlock signature(signer.MaxSignatureLength());
    signer.SignMessage(rng, (const byte*)message.data(), message.size(), signature);

    std::string signatureStr;
    StringSource ss(signature, signature.size(), true, new HexEncoder(new StringSink(signatureStr)));
    return signatureStr;
}

bool ReputationCommunicationApp::verifyMessage(const std::string& message, const std::string& signature, const CryptoPP::RSA::PublicKey& pubKey)
{
    //RSASS<PSSR, SHA256>::Verifier verifier(pubKey);

    //std::string decodedSignature;
    //StringSource ss(signature, true, new HexDecoder(new StringSink(decodedSignature)));

    return true;//verifier.VerifyMessage((const byte*)message.data(), message.size(), (const byte*)decodedSignature.data(), decodedSignature.size());
}

std::string ReputationCommunicationApp::signCertificate(const std::string& certificate)
{
    return signMessage(certificate, caPrivateKey);
}

bool ReputationCommunicationApp::verifyCertificate(const std::string& certificate)
{
    // Decode the certificate
    //std::string decodedCert;
    //StringSource ss(certificate, true, new HexDecoder(new StringSink(decodedCert)));

    // Verify the certificate using the CA's public key
    return true; //verifyMessage(decodedCert, certificate, caPublicKey);
}

void ReputationCommunicationApp::sendDENMMessage()
{
    EV << "Vehicle " << MNodeId << " detecting condition and preparing to send DENM message." << endl;

    ReputationCommunicationAppMessage* wsm = new ReputationCommunicationAppMessage();
    populateWSM(wsm);

    // Send message depending on accident status
    if (HasAccident) {
        wsm->setDemoData("Accident ahead, change route.");
        EV << "Accident detected: Node " << MNodeId << " reports 'Accident ahead, change route.'" << endl;
    } else {
        wsm->setDemoData("No accident, road is clear.");
        EV << "No accident detected: Node " << MNodeId << " reports 'No accident, road is clear.'" << endl;
    }

    wsm->setSenderAddress(MNodeId);
    wsm->setTimestamp(simTime());

    // Select a certificate for signing the message
    NodeState& myNode = MyNodeList.front();  // Ensure this is valid; adjust indexing if necessary
    int certIndex = rand() % 100;  // Pick a random certificate for this message
    wsm->setCertificate(myNode.certificates[certIndex].c_str());

    EV << "Vehicle " << MNodeId << " selected pseudonym certificate " << certIndex << " and signing message." << endl;

    // Sign the message
    std::string signature = signMessage(wsm->getDemoData(), myNode.privateKeys[certIndex]);
    wsm->setSignature(signature.c_str());

    // Attach the reputation score
    double myScore = GetReputationScoreofNode(MNodeId);
    wsm->setReputationValue(myScore);

    EV << "DENM message created and signed by Vehicle " << MNodeId << " with reputation score " << myScore << endl;

    // Send the message on SCH or CCH based on the configuration
    if (dataOnSch) {
        startService(Channel::sch2, 42, "Traffic Information Service");
        scheduleAt(computeAsynchronousSendingTime(1, ChannelType::service), wsm);
    } else {
        sendDown(wsm);
    }

    // Log the message and certificate
    sentMessage = true;
    messagesSent++;
    EV << "DENM message sent from Vehicle " << MNodeId << ": " << wsm->getDemoData() << endl;
    EV << "Certificate chosen: " << myNode.certificates[certIndex] << endl;
    EV << "Message signature: " << wsm->getSignature() << endl;
    EV << "Sender Address: " << wsm->getSenderAddress() << endl;
}

void ReputationCommunicationApp::simulateSybilAttack()
{
    EV << "Sybil attack initiated by Node " << MNodeId << endl;

    for (int i = 0; i < 5; ++i) {  // Sending multiple incorrect messages
        ReputationCommunicationAppMessage* wsm = new ReputationCommunicationAppMessage();
        populateWSM(wsm);

        // Create incorrect message depending on the accident state
        if (HasAccident) {
            // If there is an accident, Sybil attacker says there's no accident
            wsm->setDemoData("No accident, road is clear.");
            EV << "Sybil attacker Node " << MNodeId << " falsely reports no accident." << endl;
        } else {
            // If there is no accident, Sybil attacker says there's an accident
            wsm->setDemoData("Accident ahead, change route.");
            EV << "Sybil attacker Node " << MNodeId << " falsely reports an accident." << endl;
        }

        wsm->setSenderAddress(MNodeId + 200 + i);  // Adjust for Sybil attack with fake ID
        wsm->setTimestamp(simTime());

        NodeState& myNode = MyNodeList.front();
        int certIndex = rand() % 100;
        wsm->setCertificate(myNode.certificates[certIndex].c_str());

        std::string signature = signMessage(wsm->getDemoData(), myNode.privateKeys[certIndex]);
        wsm->setSignature(signature.c_str());

        // Forward the incorrect message
        if (dataOnSch) {
            startService(Channel::sch2, 42, "Traffic Information Service");
            scheduleAt(computeAsynchronousSendingTime(1, ChannelType::service), wsm);
        } else {
            sendDown(wsm);
        }


        // Decay reputation after multiple Sybil attack messages
                double reputationScore = GetReputationScoreofNode(MNodeId);
                reputationScore -= 0.1; // Decrease reputation
                if (reputationScore < 0) reputationScore = 0; // Limit reputation decay to 0
                UpdateReputationKnowledge(MNodeId, reputationScore); // Update the reputatio
        messagesSent++;

        EV << "Sybil attack message sent from Vehicle " << MNodeId << ": " << wsm->getDemoData() << endl;
        EV << "Certificate chosen: " << myNode.certificates[certIndex] << endl;
        EV << "Message signature: " << wsm->getSignature() << endl;
        EV << "Sender Address: " << wsm->getSenderAddress() << endl;
    }
}


void ReputationCommunicationApp::GenerateFile()
{
    std::fstream my_file;
    my_file.open(ReputationFile, std::ios::out);
    if (!my_file) {
        std::cout << "File not created";
    } else {
        for (int i = 0; i < 200; i++) {
            my_file << i << " " << uniform(0.0, 1.0) << " " << 0 << " " << (uniform(0.0, 1.0) > 0.5 ? 1 : 0) << std::endl;
        }
        my_file.close();
        EV << "Reputation file generated successfully." << endl;
    }
}

void ReputationCommunicationApp::ReadReputationFile()
{
    std::fstream my_file;
    std::string line;
    my_file.open(ReputationFile, std::ios::in);
    if (!my_file.is_open()) {
        std::cout << "File not created";
    } else {
        while (getline(my_file, line)) {
            std::stringstream ss(line);
            int Id;
            bool stat;
            double score;
            bool cert_valid;

            ss >> Id >> score >> stat >> cert_valid;
            NodeState AStat;
            AStat.NodeId = Id;
            AStat.NodeScore = score;
            AStat.Attacker = (stat == 1);
            AStat.validCertificate = cert_valid;
            MyScoreList.push_back(AStat);
        }
        my_file.close();
        EV << "Reputation file read successfully." << endl;
    }
}

void ReputationCommunicationApp::SetMyReputationState()
{
    for (const auto& elem : MyScoreList) {
        if (elem.NodeId == MNodeId) {
            Attacker = elem.Attacker;
            MScore = elem.NodeScore;
            EV << "Set reputation state for Node " << MNodeId << ": Attacker=" << Attacker << ", Score=" << MScore << endl;
            return;
        }
    }
}

double ReputationCommunicationApp::GetReputationScoreofNode(int nodeId)
{
    for (const auto& elem : MyScoreList) {
        if (elem.NodeId == nodeId) {
            EV << "Found reputation score " << elem.NodeScore << " for Node " << nodeId << endl;
            return elem.NodeScore;
        }
    }
    EV << "Node ID " << nodeId << " not found in reputation list." << endl;
    return -1.0;
}

void ReputationCommunicationApp::UpdateReputationKnowledge(int nodeId, double score)
{
    for (auto& elem : MyScoreList) {
        if (elem.NodeId == nodeId) {
            elem.NodeScore = score;
            EV << "Updated reputation score to " << score << " for Node " << nodeId << endl;
            return;
        }
    }
    NodeState newNode;
    newNode.NodeId = nodeId;
    newNode.NodeScore = score;
    newNode.Attacker = false;
    MyScoreList.push_back(newNode);
    EV << "Added new Node " << nodeId << " with reputation score " << score << endl;
}

void ReputationCommunicationApp::logAttackDetails(const std::string& action) {
    std::string location = mobility->getRoadId();
    double range = traciVehicle->getLanePosition();
    simtime_t time = simTime();
    EV << "Sybil Attack: Route is clear!. No accident " << action
       << " by Node=" << MNodeId
       << " at Location=" << location
       << " within Range=" << range << " meters"
       << " at time " << time << endl;

    recordScalar(("Attack_" + action + "_Time").c_str(), time);
    recordScalar(("Attack_" + action + "_Range").c_str(), range);
}

void ReputationCommunicationApp::updateDisplayString(const std::string& info) {
    findHost()->getDisplayString().setTagArg("t", 0, info.c_str());
    if (Attacker) {
        findHost()->getDisplayString().setTagArg("i", 1, "red");
    }
}
