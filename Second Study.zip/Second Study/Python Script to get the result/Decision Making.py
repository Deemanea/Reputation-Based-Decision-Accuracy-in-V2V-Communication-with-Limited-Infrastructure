import pandas as pd
import matplotlib.pyplot as plt


file_1_path = 
file_2_path = 

file_1_df = pd.read_excel(file_1_path)
file_2_df = pd.read_excel(file_2_path)


TruePositive_1 = file_1_df[['node', 'TruePositive']]
TruePositive_2 = file_2_df[['node', 'TruePositive']]


merged_df = pd.merge(TruePositive_1, TruePositive_2, left_on='node', right_on='node', suffixes=('_file1', '_file2'))

merged_df = merged_df.head(100)


plt.figure(figsize=(12, 6))


bar_width = 0.31
colors = ['green', 'purple']

bar_positions_1 = range(len(merged_df))
bar_positions_2 = [pos + bar_width for pos in bar_positions_1]

plt.bar(bar_positions_1, merged_df['TruePositive_file1'], width=bar_width, label='CRVA', color=colors[0])
plt.bar(bar_positions_2, merged_df['TruePositive_file2'], width=bar_width, label='CPCA', color=colors[1])

plt.xlabel('Time (Seconds)', fontsize=18, fontweight='bold')
plt.ylabel('True Positive Metrics', fontsize=18, fontweight='bold')

plt.xticks(fontsize=16, fontweight='bold')  # Make x-axis tick labels larger
plt.yticks(fontsize=16, fontweight='bold')  # Make y-axis tick labels larger


plt.legend(prop={'size': 18, 'weight': 'bold'})  # Use prop to set font size and weight


plt.grid(True)

plt.tight_layout()  # Ensure layout is adjusted
plt.show()
