import pandas as pd
import matplotlib.pyplot as plt

comparison_file_path = 


comparison_df = pd.read_csv(comparison_file_path)

filtered_df = comparison_df[
    (comparison_df['Precision_PC'] != 0) & (comparison_df['Precision_RV'] != 0) &
    (comparison_df['Recall_PC'] != 0) & (comparison_df['Recall_RV'] != 0) &
    (comparison_df['F1 Score_PC'] != 0) & (comparison_df['F1 Score_RV'] != 0)
]

x_ticks = filtered_df['node']  



fig, axes = plt.subplots(3, 1, figsize=(18, 12))


axes[0].plot(filtered_df['node'], filtered_df['Precision_PC'], label='CPCA', color='orange', linewidth=2)
axes[0].plot(filtered_df['node'], filtered_df['Precision_RV'], label='CRVA', color='cyan', linewidth=2)
#axes[0].set_title('Precision Comparison ')
axes[0].set_xlabel('Time (Hours)', fontsize=18, fontweight='bold')
axes[0].set_ylabel('Precision', fontsize=18, fontweight='bold')
axes[0].tick_params(axis='x', labelsize=16)  # Increase font size for x-axis numbers
axes[0].tick_params(axis='y', labelsize=16)  # Increase font size for y-axis numbers
#axes[0].set_xticks(x_ticks)  # Set the x-ticks as customized
axes[0].legend(prop={'size': 16, 'weight': 'bold'})

axes[0].grid(True)


axes[1].plot(filtered_df['node'], filtered_df['Recall_PC'], label='CPCA', color='orange', linewidth=2)
axes[1].plot(filtered_df['node'], filtered_df['Recall_RV'], label='CRVA', color='cyan', linewidth=2)
#axes[1].set_title('Recall Comparison')
axes[1].set_xlabel('Time (Hours)', fontsize=18, fontweight='bold')
axes[1].set_ylabel('Recall', fontsize=18, fontweight='bold')

#axes[1].set_xticks(x_ticks)  # Set the x-ticks as customized
axes[1].legend(prop={'size': 16, 'weight': 'bold'})
axes[1].tick_params(axis='x', labelsize=16)  # Increase font size for x-axis numbers
axes[1].tick_params(axis='y', labelsize=16)


axes[1].grid(True)



axes[2].plot(filtered_df['node'], filtered_df['F1 Score_PC'], label='CPCA', color='orange', linewidth=2)
axes[2].plot(filtered_df['node'], filtered_df['F1 Score_RV'], label='CRVA', color='cyan', linewidth=2)
#axes[2].set_title('F1 Score Comparison ')
axes[2].set_xlabel('Time (Hours)', fontsize=18, fontweight='bold')
axes[2].set_ylabel('F1 Score', fontsize=18, fontweight='bold')
#axes[2].set_xticks(x_ticks)  # Set the x-ticks as customized
axes[2].legend()
axes[2].legend(prop={'size': 16, 'weight': 'bold'}) # Use prop to set font size and weight

axes[2].tick_params(axis='x', labelsize=16)  # Increase font size for x-axis numbers
axes[2].tick_params(axis='y', labelsize=16)

# Add grid
plt.grid(True)





plt.tight_layout()  # Ensure layout is adjusted
plt.show()

