import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

pc_accident_path =
rv_accident_path =


pc_accident_df = pd.read_excel(pc_accident_path)
rv_accident_df = pd.read_excel(rv_accident_path)


pc_tp = pc_accident_df['TruePositive'].sum()
pc_tn = pc_accident_df['TrueNegative'].sum()
pc_fp = pc_accident_df['FalsePositive'].sum()
pc_fn = pc_accident_df['FalseNegative'].sum()

rv_tp = rv_accident_df['TruePositive'].sum()
rv_tn = rv_accident_df['TrueNegative'].sum()
rv_fp = rv_accident_df['FalsePositive'].sum()
rv_fn = rv_accident_df['FalseNegative'].sum()

pc_values = [pc_tp, pc_tn, pc_fp, pc_fn]
rv_values = [rv_tp, rv_tn, rv_fp, rv_fn]
labels = ['True Positives (TP)', 'True Negatives (TN)', 'False Positives (FP)', 'False Negatives (FN)']


fig, ax = plt.subplots(figsize=(12, 6))


bar_width = 0.22
index = np.arange(len(labels))  # Labels: TP, TN, FP, FN


pc_bars = ax.bar(index, pc_values, bar_width, label='CPCA', color='maroon')
rv_bars = ax.bar(index + bar_width, rv_values, bar_width, label='CRVA', color='olive')


#ax.set_title('Comparison of TP, TN, FP, FN Totals for PC and RV Systems', fontsize=14)
ax.set_xlabel('Metrics', fontsize=12)
ax.set_ylabel('Count', fontsize=12)
ax.set_xticks(index + bar_width / 1)
ax.set_xticklabels(labels)


ax.legend()

plt.tight_layout()
plt.show()
